package loop.test;

import loop.sample.ForSample;

public class TestForSample {

	public static void main(String[] args) {
		// ForSample ���� �׽�Ʈ��
		ForSample fsamp = new ForSample();
		//fsamp.testFor1();
		//fsamp.testFor2();
		//fsamp.testFor3();
		fsamp.testFor4();
	}

}
