package loop.test;

import loop.sample.DoWhileSample;

public class TestDoWhileSample {

	public static void main(String[] args) {
		// do~while loop test
		DoWhileSample dwsamp = 
				new DoWhileSample();
		//dwsamp.testDoWhile1();
		//dwsamp.testDoWhile2();
		//dwsamp.testDoWhile3();
		//dwsamp.testDoWhile4();
		//dwsamp.testDoWhile4for();
		dwsamp.testDoWhile4while();
	}

}





