package day29.silsub;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class GUITCPMultiChattingClient extends JFrame {
	//Field
	private Socket client;
	
	private JTextArea tarea;
	private JTextField textf;
	private JTextField idTextf;
	private JPasswordField pwdTextf;
	
	private JButton connectBtn;
	private JButton sendBtn;
	private JButton exitBtn;
	
	private PrintWriter output;
	private BufferedReader input;
	private String message;
		
	public GUITCPMultiChattingClient()
	{
		super("TCP ��� Ŭ���̾�Ʈ");
		
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension screenSize = tk.getScreenSize();
		int width = (int)screenSize.getWidth();
		int height = (int)screenSize.getHeight();
		this.setBounds(0, 0, (width - 600), (height - 50));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
		
		Font textFont = new Font("�޸ո���T", Font.PLAIN, 14);
		
		tarea = new JTextArea();
		tarea.setSize(580, height - 300);
		tarea.setFont(textFont);
		JScrollPane scrollP = new JScrollPane(tarea);
		
		exitBtn = new JButton("Ŭ���̾�Ʈ����");
		exitBtn.addActionListener(new ExitBtnHandler());
		
		connectBtn = new JButton("�� �� ��");
		connectBtn.addActionListener(new ConnectBtnHandler());
		
		idTextf = new JTextField(20);
		idTextf.setFont(textFont);
		pwdTextf = new JPasswordField(20);
		pwdTextf.setFont(textFont);
		pwdTextf.setEchoChar('*');
				
		JPanel loginPane = new JPanel();
		loginPane.setLayout(new GridLayout(2, 2));
		loginPane.add(new JLabel("���̵� : "));
		loginPane.add(idTextf);
		loginPane.add(new JLabel("��  ȣ : "));
		loginPane.add(pwdTextf);
		
		JPanel northPane = new JPanel();
		northPane.add(loginPane);
		northPane.add(connectBtn);
		northPane.add(exitBtn);
		
		JLabel label = new JLabel("���� �޼��� : ");
		textf = new JTextField(40);
		textf.setFont(textFont);
		sendBtn = new JButton("����");
		sendBtn.addActionListener(new SendBtnHandler());
		
		JPanel southPane = new JPanel();
		southPane.add(label);
		southPane.add(textf);
		southPane.add(sendBtn);
		
		this.add(scrollP, BorderLayout.CENTER);
		this.add(northPane, BorderLayout.NORTH);	
		this.add(southPane, BorderLayout.SOUTH);
		
		this.setVisible(true);
				
		tarea.append("���� : ���� ��� �����Դϴ�...\n");
				
	}
	
	//������ �޼��� ������ �ؽ�Ʈ����� ����ϴ� �޼ҵ�
	public void sendMessage()
	{
		String message = textf.getText();
	
		output.println("���� : " + message);
		output.flush();
		tarea.append("���� : " + message + "\n");
				
		if(message.equals("quit"))
		{				
			tarea.append("server disconnected.........\n");
						
			try {
				input.close();
				output.close();
				client.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
	
	//�����κ��� �޼��� �޾Ƽ� �ؽ�Ʈ����� ����ϴ� �޼ҵ�
	public void recieveMessage()
	{
		try{
			if(message == null)		//ó�� ���� �޼����� ��
			{
				message = input.readLine();
				if(message.equals("�α��� ����"))
				{
					tarea.append(message + "\n");
					
					input.close();
					output.close();
					client.close();
				}
			}
			
			tarea.append(input.readLine() + "\n");
			
		}catch(IOException e){
			e.printStackTrace();
		}
	}	
		
	//���� ��ư Ŭ�� ó���� �̺�Ʈ�ڵ鷯 Ŭ���� ------------------------
	private class ExitBtnHandler implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent event)
		{
			int result = JOptionPane.showOptionDialog(getParent(), 
					"������ Ŭ���̾�Ʈ�� �����Ͻðڽ��ϱ�?", "����Ȯ��",
					JOptionPane.YES_OPTION,
					JOptionPane.QUESTION_MESSAGE, null,
					new String[]{"����", "���"}, "����");
			if(result == 0){
				try{					
					input.close();
					output.close();
					client.close();
				}catch(IOException e)
				{
					e.printStackTrace();
				}finally{
					System.exit(0);
				}
			}
		}		
	}
	
	//���� ���� ��ư ó���� �̺�Ʈ�ڵ鷯 -----------------------------
	private class ConnectBtnHandler implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent event)
		{
			int port = 9000;
			String serverIp = "127.0.0.1";
			
			try{
				client = new Socket(serverIp, port);
				String loginMessage = idTextf.getText() + "," + 
							new String(pwdTextf.getPassword());
				message = null;
				
				input = new BufferedReader(
						new InputStreamReader(client.getInputStream()));
				output = new PrintWriter(client.getOutputStream());
				
				output.println(loginMessage);
				output.flush();
				recieveMessage();
				
			}catch(UnknownHostException e)
			{
				e.printStackTrace();
			}catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}
	
	//���� ��ư Ŭ�� �̺�Ʈ�ڵ鷯 ---------------------------------------
	private class SendBtnHandler implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			sendMessage();
			recieveMessage();
		}
	}
	
	public static void main(String[] args) {
		// GUI �� TCP Ŭ���̾�Ʈ�� ���α׷�
		new GUITCPMultiChattingClient();
	}

}
