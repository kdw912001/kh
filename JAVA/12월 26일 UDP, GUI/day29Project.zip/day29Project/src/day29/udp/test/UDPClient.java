package day29.udp.test;

import java.net.*;

public class UDPClient {

	public UDPClient()
	{
		byte[] recvMessage = new byte[100];
		DatagramSocket clientSocket = null;
		
		try {
			clientSocket = new DatagramSocket(9999);			
						
			DatagramPacket dp = new DatagramPacket(recvMessage, 
					recvMessage.length);
			
			while(true){
				System.out.println("���� �غ�.....");
				clientSocket.receive(dp);
				String message = new String(dp.getData());
			
				System.out.println("���� �޼��� : " + message);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			clientSocket.close();
		}
		
	}
	
	public static void main(String[] args) {
		// UDP ���� Ŭ���̾�Ʈ�� ���α׷�
		System.out.println("Ŭ���̾�Ʈ ����");
		new UDPClient();
		
	}

}
