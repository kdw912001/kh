package oop.run;

import oop.model.vo.TestAccess;

public class TestOOp {

	public static void main(String[] args) {
		// oop test
		TestAccess ta = new TestAccess();
		ta.test();

	}

}
