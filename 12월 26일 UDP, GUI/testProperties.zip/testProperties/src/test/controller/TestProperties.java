package test.controller;

import java.io.*;
import java.util.*;

import test.entity.Employee;

public class TestProperties {

	public static void main(String[] args) {
		// day23 �Ǳ��׽�Ʈ
		TestProperties test = new TestProperties();
		Properties prop = new Properties();

		Employee[] er = test.readFile(prop);
		test.printConsole(prop);
		System.out.println();
		test.addEmpData(prop);
		test.printConsole(prop);
		test.saveEmpXML(er);		
	}

	public void addEmpData(Properties p)
	{
		Employee e1 = new Employee(20070225, "Ȳ����", "���ߺ�", 83000000, 0.25);
		String value1 = e1.geteName() + ", " + e1.getDept() + ", " + 
				e1.getSalary() + ", " + e1.getBonusPoint();
		p.setProperty(String.valueOf(e1.geteId()), value1);
		
		Employee e2 = new Employee(20150310, "������", "���ߺ�", 28000000, 0.05);
		String value2 = e2.geteName() + ", " + e2.getDept() + ", " + 
				e2.getSalary() + ", " + e2.getBonusPoint();
		p.setProperty(String.valueOf(e2.geteId()), value2);
	}
	
	public Employee[] readFile(Properties p)
	{
		Employee[] ear = null;
		
		try {
			p.load(new FileReader("empData.txt"));
			ear = new Employee[p.size()];
			
			Set<String> keys = p.stringPropertyNames();
			Iterator<String> keyList = keys.iterator();
			
			int i = 0;
			while(keyList.hasNext())
			{
				String key = keyList.next();
				String value = p.getProperty(key);
				String[] fieldValues = value.split(", ");
				
				ear[i] = new Employee(Integer.parseInt(key),
						fieldValues[0], fieldValues[1],
						Integer.parseInt(fieldValues[2]),
						Double.parseDouble(fieldValues[3]));
				i++;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return ear;
	}
	
	public void printConsole(Properties p)
	{
		Set<String> keys = p.stringPropertyNames();
		Iterator<String> keyList = keys.iterator();
		
		while(keyList.hasNext())
		{
			String key = keyList.next();
			String value = p.getProperty(key);
			System.out.println(key + ", " + value);
		}
	}
	
	public void saveEmpXML(Employee[] er)
	{
		Properties p = new Properties();
		
		for(int i = 0; i < er.length; i++)
		{
			double yearSalary = er[i].getSalary() + (er[i].getSalary() * er[i].getBonusPoint());
			String value = er[i].geteName() + ", " + er[i].getDept() + 
					", " + er[i].getSalary() + ", " + er[i].getBonusPoint()
					+ ", " + (int)yearSalary;
			p.setProperty(String.valueOf(er[i].geteId()), value);
		}
		
		try {
			p.storeToXML(new FileOutputStream("empResult.xml"),
					"Employee Result File", "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	} 	
	
}
