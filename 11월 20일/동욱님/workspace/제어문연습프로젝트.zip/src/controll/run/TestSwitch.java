package controll.run;

import controll.sample.SwitchSample;

public class TestSwitch {

	public static void main(String[] args) {
		//SwitchSample �����
		SwitchSample ss = new SwitchSample();
		//ss.testSwitch1();
		//ss.testSwitch2();
		//ss.testSwitch3();
		/*ss.testSwitch4();
		System.out.println("���α׷��� ����");*/
		//ss.testSwitch5();
		ss.testSwitch6();
	} //main

}
