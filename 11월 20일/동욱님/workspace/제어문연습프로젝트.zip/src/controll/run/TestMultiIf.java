package controll.run;

import controll.sample.MultiIfSample;

public class TestMultiIf {

	public static void main(String[] args) {
		// MultiIfSample test ��
		MultiIfSample msamp = new MultiIfSample();
		//msamp.testMulti1();
		//msamp.testMulti2();
		//msamp.testMulti3();
		msamp.testMulti4();

	}

}
