package controll.run;

import controll.sample.IfElseSample;

public class TestIfElse {

	public static void main(String[] args) {
		// IfElseSample test ��
		IfElseSample samp = new IfElseSample();
		//samp.testIfElse1();
		//samp.testIfElse2();
		samp.testIfElse3();
	}

}
