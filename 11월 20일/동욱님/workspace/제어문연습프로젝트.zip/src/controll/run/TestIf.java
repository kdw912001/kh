package controll.run;

import controll.sample.IfSample;

public class TestIf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IfSample isamp = new IfSample();
		//isamp.unicodeToChar();
		//isamp.unicodeToChar2();
		//isamp.ifExample2();
		//static �޼ҵ带 �θ����� Ŭ������.�޼ҵ�();
		//isamp.ifExample3();
		//isamp.ifExample4();
		//isamp.ifElseExample1();
		//isamp.ifElseExample2();
		isamp.ifElseExample3();
	}

}
