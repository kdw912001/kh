package product.run;

import product.view.ProductView;

public class GUIProductRun {

	public static void main(String[] args) {
		// GUI 상품관리 프로그램 실행
		new ProductView();

	}

}
